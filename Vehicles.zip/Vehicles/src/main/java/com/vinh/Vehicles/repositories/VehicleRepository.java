package com.vinh.Vehicles.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.vinh.Vehicles.models.Vehicle;

@Repository
public interface VehicleRepository extends CrudRepository<Vehicle, Long>{
	List<Vehicle> findAll(); //Select * FROM Vehicles
}
