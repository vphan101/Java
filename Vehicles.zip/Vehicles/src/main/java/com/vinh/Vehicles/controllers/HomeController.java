package com.vinh.Vehicles.controllers;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.vinh.Vehicles.models.Title;
import com.vinh.Vehicles.services.TitleService;
import com.vinh.Vehicles.services.VehicleService;

@Controller
public class HomeController {
	@Autowired
	private VehicleService vService;
	@Autowired
	private TitleService tService;
	
	
	@GetMapping("/")
	public String index(Model viewModel) {
		viewModel.addAttribute("vehicles", this.vService.getAllVehicles());
		return "index.jsp";
	}
	
	@GetMapping("/add")
	public String add() {
		return "add.jsp";
	}
	
	//@PostMapping("/addCar")
	//public String addCar(@RequestParam("make") String make, @RequestParam("model") String model,@RequestParam("year") int year,@RequestParam("color") String color,@RequestParam("transmission") String transmission) {
	//	this.vService.createVehicle(make, model, model, color, transmission);
	//	return "redirect:/";
	//}
	
	@PostMapping("/addCar")
	public String addCar(@RequestParam("make") String make,@RequestParam("model") String model, @RequestParam("year") int year, @RequestParam("color") String color,@RequestParam("transmission") String transmission, RedirectAttributes redirectAttrs) {
		//System.out.println(make, model);
		ArrayList<String> errors = new ArrayList<String>();
		if(make.equals("")) {
			errors.add("Hey there, you forgot to add a make");
		}
		if(errors.size() > 0) {
			for(String e : errors) {
				redirectAttrs.addFlashAttribute("errors", e);
			}
			return "redirect:/add";
		}
		this.vService.createVehicle(make, model, year, color, transmission);
		return "redirect:/";
	}
		
	
	@GetMapping("{id}")
	public String updateVehicle(@PathVariable("id")Long id, Model viewModel, @ModelAttribute("title") Title title) {
		viewModel.addAttribute("vehicle", vService.getSingleVehicle(id));
		return "show.jsp";
	}
	
	@PostMapping("/addTitle")
	public String addTitle(@Valid @ModelAttribute("title") Title title, BindingResult result, Model viewModel) {
		Long vehicleId = title.getVehicle().getId();
		if(result.hasErrors()) {
			viewModel.addAttribute("vehicle", vService.getSingleVehicle(vehicleId));
			return "show.jsp";
		}
		else {
			this.tService.create(title);
			return "redirect:/" + vehicleId;
		}
	}
	
}
