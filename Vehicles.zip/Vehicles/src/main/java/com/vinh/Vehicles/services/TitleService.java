package com.vinh.Vehicles.services;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.vinh.Vehicles.models.Title;
import com.vinh.Vehicles.repositories.TitleRepository;

@Service
public class TitleService {
	@Autowired
	private TitleRepository tRepo;
	
	//Create
	public Title create(Title title) {
		return this.tRepo.save(title);
	}
	
	
	
}
