package com.vinh.Vehicles.services;

import java.util.List;


import org.springframework.stereotype.Service;

import com.vinh.Vehicles.models.Vehicle;
import com.vinh.Vehicles.repositories.VehicleRepository;

@Service
public class VehicleService {
	//Dependency Injection
	private VehicleRepository vRepo;
	
	public VehicleService(VehicleRepository repo) {
		this.vRepo = repo;
	}
	
	//Get ALL Vehicles
	public List<Vehicle> getAllVehicles(){
		return this.vRepo.findAll();
	}
	
	//Get One Vehicle
	public Vehicle getSingleVehicle(Long id) {
		return this.vRepo.findById(id).orElse(null);
	}
	
	//Create a Vehicle
	public Vehicle createVehicle(Vehicle newVehicle) {
		return this.vRepo.save(newVehicle);
	}
	
	//Delete a Vehicle
	public void deleteVehicle(Long id) {
		this.vRepo.deleteById(id);
	}
	
	//Update a Vehicle
	public Vehicle updateVehicle(Vehicle vehicle) {
		return this.vRepo.save(vehicle);
	}
	
	///Will push to the database
	public Vehicle createVehicle(String make,String model,int year,String color,String transmission ) {
		Vehicle newVehicle = new Vehicle(make,model,year,color,transmission);
		return this.vRepo.save(newVehicle);
	}
	
}
