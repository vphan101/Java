package com.vinh.Vehicles.controllers;

import java.util.List;


import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.vinh.Vehicles.models.Vehicle;
import com.vinh.Vehicles.services.VehicleService;

@RestController
@RequestMapping("/api")
public class APIController {
	private VehicleService vService;
	
	
	public APIController(VehicleService service) {
		this.vService = service;
	}
	
	//Routes
	@RequestMapping("")
	public List<Vehicle> index(){
		return this.vService.getAllVehicles();
		
	}
	
	@RequestMapping("/{id}")
	public Vehicle getVehicle(@PathVariable("id") Long id) {
		return this.vService.getSingleVehicle(id);
	}
	
	@RequestMapping(value="", method=RequestMethod.POST)
	public Vehicle create(Vehicle vehicle) {
		return this.vService.createVehicle(vehicle);
	}
	
	@RequestMapping(value="/delete/{id}", method=RequestMethod.DELETE)
	public void deleteVehicle(@PathVariable("id") Long id) {
		this.vService.deleteVehicle(id);
	}
	
	//@PutMapping("/update/{id}")
	//public Vehicle edit(@PathVariable("id") Long id) {
	//	this.vService.updateVehicle(updatedVehicle);
	//}
	
	//@RequestMapping(value="/update/{id}", method=RequestMethod.PUT)
	//public void updateVehicle(@PathVariable("id") Long id, Vehicle updatedVehicle) {
	//	return this.vService.updateVehicle(updatedVehicle);
	//}
	
}
