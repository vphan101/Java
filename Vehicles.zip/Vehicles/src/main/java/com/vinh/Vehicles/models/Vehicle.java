package com.vinh.Vehicles.models;


import java.util.Date;


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="Vehicles")
public class Vehicle {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	@Size(min=1, max=20)
	private String make;
	@NotBlank
	private String model;
	private int year;
	@NotBlank
	private String color;
	private String transmission;
	
	///for Title( one to one relationship)
	@OneToOne(mappedBy="vehicle", cascade=CascadeType.ALL, fetch=FetchType.LAZY)
	private Title title;
	
	public Title getTitle() {
		return title;
	}

	public void setTitle(Title title) {
		this.title = title;
	}
	
	@Column(updatable=false)
	@DateTimeFormat(pattern = "yyyy-MM-DD: HH:mm:ss")
	private Date createdAt;
	@DateTimeFormat(pattern = "MM-DD-YYYY HH:mm:ss")
	private Date updatedAt;
	
	@PrePersist
	protected void onCreate() {
		this.createdAt  = new Date();
	}
	
	@PreUpdate
	protected void onUpdte() {
		this.updatedAt = new Date();
	}
	
	
	public Vehicle() {
		
	}

	
	public Vehicle(String make, String model, int year, String color, String transmission) {
	
		this.make = make;
		this.model = model;
		this.year = year;
		this.color = color;
		this.transmission = transmission;
	}



	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getTransmission() {
		return transmission;
	}

	public void setTransmission(String transmission) {
		this.transmission = transmission;
	}

	///for PrePersist and PreUpdate is for Server-Side validation
	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	

	
	
	

	
  
	
	
	
	
	
}
