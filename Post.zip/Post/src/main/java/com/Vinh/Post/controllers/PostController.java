package com.Vinh.Post.controllers;

import org.springframework.stereotype.Controller;


import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class PostController {
	@RequestMapping(value="/", method=RequestMethod.GET)
	public String helloWorld() {
		//return "Hello World, Hi Vinh";
		return "index.jsp";
	}
	
	//@RequestMapping(value="/login", method=RequestMethod.POST)
	//private String submitjoke(@RequestParam(value="name")String name, @RequestParam(value="email")String email, Model viewModel) {
	//	viewModel.addAttribute("name", name);
		//viewModel.addAttribute("password", password);
	//	viewModel.addAttribute("email", email);
		
	//	return "loginresult.jsp";
	//}
	
	@RequestMapping(value="/loginsubmit", method=RequestMethod.POST)
	private String login(@RequestParam(value="name")String name, @RequestParam(value="email")String email, @RequestParam(value="password") String password, Model viewModel) {
		viewModel.addAttribute("name", name);
		viewModel.addAttribute("email", email);
		viewModel.addAttribute("password", password);
		return "loginresult.jsp";
	}
}
