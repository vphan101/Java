package com.vinh.dogs.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vinh.dogs.models.Toy;
import com.vinh.dogs.repositories.ToyRepository;

@Service
public class ToyService {
	@Autowired
	private ToyRepository tRepo;
	
	
	//Create
	public Toy create(Toy toy) {
		return this.tRepo.save(toy);
	}
	
	
}
