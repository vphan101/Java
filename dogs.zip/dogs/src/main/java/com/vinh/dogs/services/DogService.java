package com.vinh.dogs.services;

import java.util.List;


import org.springframework.stereotype.Service;
import com.vinh.dogs.models.Dog;
import com.vinh.dogs.repositories.DogRepository;

@Service
public class DogService {
	//Dependency Injection
	private DogRepository cRepo;
	
	public DogService(DogRepository repo) {
		this.cRepo = repo;
	}
	
	//Get All Dogs
	public List<Dog> getAllDogs(){
		return this.cRepo.findAll();
	}
	
	//Get One Dog
	public Dog getSingleDog(Long id) {
		return this.cRepo.findById(id).orElse(null);
	}
	
	//Create a Dog
	public Dog createDog(Dog newDog) {
		return this.cRepo.save(newDog);
	}
	
	//Delete a Dog
	public void deleteDog(Long id) {
		this.cRepo.deleteById(id);
	}
	
	//Update a Dog
	public Dog updateDog(Dog dog) {
		return this.cRepo.save(dog);
	}
	
	//Will push it to the database
	//Create a Dog
	public Dog createDog(String name, String breed, int age, String color) {
		Dog newDog = new Dog(name,breed,age,color);
		return this.cRepo.save(newDog);
	}
	
}
