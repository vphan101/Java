package com.vinh.dogs.controllers;


import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.vinh.dogs.models.Dog;
import com.vinh.dogs.models.Toy;
import com.vinh.dogs.services.DogService;


@Controller
public class HomeController {
	@Autowired
	private DogService cService;
	
	@GetMapping("/")
	public String index(Model viewModel) {
		viewModel.addAttribute("dogs", this.cService.getAllDogs());
		return "index.jsp";
	}

	@GetMapping("/create")
	public String create() {
		return "create.jsp";
	}
	
	
	@PostMapping("/addDog")
	public String addDog(@Valid @ModelAttribute("dog") Dog dog, BindingResult result) {
		if(result.hasErrors() ) {
			return "create.jsp";
		}
		this.cService.createDog(dog);
		return "redirect:/";
	}
	
	
	@GetMapping("/{id}")
	public String updateDog(@PathVariable("id") Long id, Model viewmodel, @ModelAttribute("toy") Toy toy) {
		viewmodel.addAttribute("dog",cService.getSingleDog(id));
		return "show.jsp";
	}

	//@Autowired
	//private ToyService tService;
	
}
