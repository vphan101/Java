package com.vinh.dogs.controllers;


import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vinh.dogs.models.Dog;
import com.vinh.dogs.services.DogService;

@RestController
@RequestMapping("/api")
public class APIController {
	//Dependency Injection
	@Autowired
	private DogService cService;
	
	@GetMapping("")
	//public String index() {
	//	return "Hello dogs";
	//}
	
	public List<Dog> index(){
		return this.cService.getAllDogs();
	}
	
	///Get a Single Dog
	@GetMapping("/{id}")
	public Dog getDog(@PathVariable("id") Long id) {
		return this.cService.getSingleDog(id);
	}
	
	//Create a Dog
	@PostMapping("")
	public Dog create(Dog dog) {
		return this.cService.createDog(dog);
	}
	
	//Delete a Dog
	@DeleteMapping("/{id}")
	public void deleteDog(@PathVariable("id") Long id) {
		this.cService.deleteDog(id);
	}
	
	
}
