package com.vinh.dosurvey.models;


public class Survey {
	private String firstname;
	private String lastname;
	private String location;
	private String language;
	private String comment;
	
	public Survey(String firstname, String lastname, String location, String language, String comment) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.location = location;
		this.language = language;
		this.comment = comment;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}
	
	
	
	
	
	
	
	
	
	
}
