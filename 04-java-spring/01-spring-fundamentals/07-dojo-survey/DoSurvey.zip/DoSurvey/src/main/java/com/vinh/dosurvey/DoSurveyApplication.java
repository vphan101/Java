package com.vinh.dosurvey;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DoSurveyApplication {

	public static void main(String[] args) {
		SpringApplication.run(DoSurveyApplication.class, args);
	}

}
