package com.vinh.dosurvey.controllers;



import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.vinh.dosurvey.models.Survey;


@Controller
public class DoSurveyController {
	@RequestMapping(value="/", method=RequestMethod.GET)
	public String index(Model model) {
		model.addAttribute("locations", new String[] {"San Jose", "Seattle","Burbank","Dallas"});
		model.addAttribute("languages", new String[] {"Python", "JavaScript","MySql","Java"});
		return "index.jsp";
	}
	
	@RequestMapping(value="/result", method=RequestMethod.POST)
	private String survey(@RequestParam(value="firstname")String firstname, @RequestParam(value="lastname")String lastname, @RequestParam(value="location") String location, @RequestParam(value="language") String language, @RequestParam(value="comment") String comment, Model model) {
		//model.addAttribute("firstname", firstname);
		//model.addAttribute("lastname", lastname);
		//model.addAttribute("location", location);
		//model.addAttribute("language", language);
		//model.addAttribute("comment", comment);
		
		model.addAttribute("result", new Survey(firstname, lastname, location, language, comment));
		return "result.jsp";
		
	}
	
	
}
