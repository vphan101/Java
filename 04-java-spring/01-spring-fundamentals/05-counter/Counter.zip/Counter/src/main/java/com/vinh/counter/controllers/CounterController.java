package com.vinh.counter.controllers;

import javax.servlet.http.HttpSession;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class CounterController {
	@RequestMapping("/")
		
		public String index(HttpSession session) {
			//return "Hello DisplayDate Assignment";
			if(session.getAttribute("count")==null) {
				session.setAttribute("count", 0);
			}
			
			Integer currentCount = (Integer)session.getAttribute("count");
			currentCount++;
			session.setAttribute("count", currentCount);
			return "index.jsp";
		}
	
	@RequestMapping("/counter")
	public String count(HttpSession session, Model model) {
		if(session.getAttribute("count")==null) {
			session.setAttribute("count", 0);
			model.addAttribute("currentCount", session.getAttribute("count"));
		}
			Integer currentCount = (Integer)session.getAttribute("count");
			session.setAttribute("count", currentCount);
			model.addAttribute("currentCount", currentCount);
			return "counter.jsp";
		}
	
	@RequestMapping("/reset")
	public String reset(HttpSession session) {
		session.setAttribute("count", 0);
		return "redirect:/counter";
	}
}
