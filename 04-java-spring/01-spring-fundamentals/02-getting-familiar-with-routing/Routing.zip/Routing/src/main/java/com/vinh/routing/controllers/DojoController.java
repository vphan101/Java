package com.vinh.routing.controllers;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DojoController {
	@RequestMapping(value="/dojo", method=RequestMethod.GET)
	public String dojo() {
		return "The dojo is awesome!";
	}
	
	//@RequestMapping(value="/dojo/San Jose", method=RequestMethod.GET)
	//public String sanjose() {
	//	return "San Jose dojo is the headquarters";
	//}
	
	@RequestMapping(value="/dojo/{location}", method=RequestMethod.GET)
	public String dojoCenter(@PathVariable("location") String location) {
		switch(location) {
		case "burbank":
			return "Burbank Dojo is located in Southern California";
		
		case "San-Jose":
			return "SJ dojo is the headquarters";
		
		default:
			return String.format("%s is pretty sweet!", location);
			
		}
		
	}
	
}
