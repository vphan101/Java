package com.vinh.lookify.repositories;

public interface SongRepository {

}
