package com.vinh.lookify.controllers;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class SongController {
	@GetMapping(value="/")
	public String index() {
		return "index.jsp";
	}
	
	@GetMapping(value="/new")
	public String newsong() {
		return "new.jsp";
	}
	
	@GetMapping(value="/show")
	public String showsong() {
		return "show.jsp";
	}
	
	@GetMapping(value="/dashboard")
	public String dashboard() {
		return "dashboard.jsp";
	}
	
	@PostMapping(value="/dashboard", method=RequestMethod.POST)
	public String createSong() {
		return "new.jsp";
	}
	
	
}
