package com.vinh.languages.services;


import java.util.List;


import org.springframework.stereotype.Service;

import com.vinh.languages.models.Language;
import com.vinh.languages.repositories.LanguageRepository;

@Service
public class LanguageService {
	private final LanguageRepository lRepo;
	
	public LanguageService(LanguageRepository repo) {
		this.lRepo = repo;
	}
	
	//find All Languages
	public List<Language> alllanguages(){
		return this.lRepo.findAll();
	}
	
	//Find One Language
	public Language findLanguage(Long id) {
		return this.lRepo.findById(id).orElse(null);
	}
	
	//Create
	public Language createLanguage(Language newlang) {
		return this.lRepo.save(newlang);
	}
	
	//Update
	public Language updateLanguage(Language updatedlang) {
		return this.lRepo.save(updatedlang);
	}
	
	//Delete
	public void deleteLanguage(Long id) {
		this.lRepo.deleteById(id);
	}
	
	
}
