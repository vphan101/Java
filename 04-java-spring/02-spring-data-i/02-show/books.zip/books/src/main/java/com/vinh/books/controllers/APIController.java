package com.vinh.books.controllers;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vinh.books.models.Book;
import com.vinh.books.services.BookService;


@RestController
@RequestMapping("/api")
public class APIController {
	//Dependency Injection
	@Autowired
	private BookService cService;
	
	
	@GetMapping("")
	//public String book() {
		//return "Hello Books";
		//return "index.jsp";
	//}
	
	public List<Book> index(){
		return this.cService.getAllBooks();
	}
	
	//Get a Single Book
	@GetMapping("/{id}")
	public Book getBook(@PathVariable("id") Long id) {
		return this.cService.getSingleBook(id);
	}
	
	//Create a Book
	@PostMapping("")
	public Book create(Book book) {
		return this.cService.createBook(book);
	}
	
	//Delete a Book
	@DeleteMapping("/{id}")
	public void deleteBook(@PathVariable("id") Long id) {
		this.cService.deleteBook(id);
	}
	
	
	
}