package com.vinh.books.controllers;


import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;


import com.vinh.books.models.Book;
import com.vinh.books.services.BookService;

@Controller
public class BookController {
	@Autowired
	private BookService cService;
	
	
	@GetMapping("/")
	public String index(Model viewModel) {
		
		viewModel.addAttribute("books", this.cService.getAllBooks());
		return "index.jsp";
	}
	
	@GetMapping("/new")
	public String add() {
		return "new.jsp";
	}
	
	@PostMapping("/newBook")
	public String newBook(@Valid @ModelAttribute("book") Book book, BindingResult result) {
		if(result.hasErrors() ) {
			return "new.jsp";
		}
		this.cService.createBook(book);
		return "redirect:/";
		//return "showbook.jsp";
	}
	
	
	
}
