package com.vinh.books.services;

import java.util.List;

import org.springframework.stereotype.Service;
import com.vinh.books.models.Book;
import com.vinh.books.repositories.BookRepository;



@Service
public class BookService {
	//Dependency Injection
	private BookRepository cRepo;
	
	public BookService(BookRepository repo) {
		this.cRepo = repo;
	}
	
	//Get All Books
	public List<Book> getAllBooks(){
		return this.cRepo.findAll()
;	}
	
	//Get One Book
	public Book getSingleBook(Long id) {
		return this.cRepo.findById(id).orElse(null);
	}
	
	//Create a Book
	public Book createBook(Book newBook) {
		return this.cRepo.save(newBook);
	}
	
	//Delete a Book
	public void deleteBook(Long id) {
		this.cRepo.deleteById(id);
	}
	
	//Create a Book
	public Book createBook(String title, String description, String language, int numofpages) {
		Book newBook = new Book(title, description, language, numofpages);
		return this.cRepo.save(newBook);
	}
	
}
