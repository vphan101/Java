package com.vinh.overflow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OverflowApplicationTests {

	@Test
	void contextLoads() {
	}

}
