package com.vinh.cars.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.vinh.cars.models.Title;


//Create for the showcar.jsp form:form from <c:otherwise>
@Repository
public interface TitleRepository extends CrudRepository<Title, Long>{

}
