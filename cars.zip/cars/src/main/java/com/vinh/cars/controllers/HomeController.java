package com.vinh.cars.controllers;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.vinh.cars.models.Car;
import com.vinh.cars.models.Title;
import com.vinh.cars.services.CarService;
import com.vinh.cars.services.TitleService;


@Controller
public class HomeController {
	@Autowired
	private CarService cService;
	
	@GetMapping("/")
	public String index(Model viewModel) {
		//List<Car> allCars = this.cService.getAllCars();
		viewModel.addAttribute("cars", this.cService.getAllCars());
		//viewModel.addAttribute("allCars", allCars);
		return "index.jsp";
	}
	
	
	@GetMapping("/add")
	public String add() {
		return "add.jsp";
	}
	
	
	//Oldway
	@PostMapping("/oldAddCar")
	public String oldAddCar(@RequestParam("make") String make,@RequestParam("model") String model, @RequestParam("year") int year, @RequestParam("color") String color, RedirectAttributes redirectAttrs) {
		//System.out.println(make, model);
		ArrayList<String> errors = new ArrayList<String>();
		if(make.equals("")) {
			errors.add("Hey there, you forgot to add a make");
		}
		if(errors.size() > 0) {
			for(String e : errors) {
				redirectAttrs.addFlashAttribute("errors", e);
			}
			return "redirect:/add";
		}
		this.cService.createCar(make,model,year,color);
		return "redirect:/";
	}
	
	//New way
	@PostMapping("/addCar")
	public String addCar(@Valid @ModelAttribute("car") Car car, BindingResult result) {
		if(result.hasErrors() ) {
			return "add.jsp";
		}
		this.cService.createCar(car);
		//return "redirect:/";
		return "showcar.jsp";
	}
	
	
	//From Title.java continued
	@GetMapping("/{id}")
	public String updateCar(@PathVariable("id") Long id, Model viewmodel, @ModelAttribute("title") Title title) {
		viewmodel.addAttribute("car",cService.getSingleCar(id));
		return "showcar.jsp";
	}
	
	
	@Autowired
	private TitleService tService;
	
	@PostMapping("/addTitle")
	public String addTitle(@Valid @ModelAttribute("title") Title title, BindingResult result, Model viewModel) {
		Long carId = title.getCar().getId();
		if(result.hasErrors()) {
			viewModel.addAttribute("car",cService.getSingleCar(carId));
			return "showcar.jsp";
		}
		else {
			this.tService.create(title);
			return "redirect:/" + carId;
		}
	}
	
	
	
	
	
	
}
